﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MySQLApp
{
    public partial class Form1 : Form
    {
        private Database DB;
        private DataTable table;
        private MySqlDataAdapter adapter;

        class Database
        {
            public String serverString;
            public String databaseString;
            public String userString;
            public String passwordString;
            public String tableString;
            public String connectionString;

            MySqlConnection connection;
            public void buildConnectionString()
            {
                connectionString = "Server=" + serverString + "; Database=" + databaseString + "; User ID=" + userString + "; Password=" + passwordString;
                connection = new MySqlConnection(connectionString);                
            }

            //MySqlConnection connection = new MySqlConnection("Server=localhost; Database=labworkn2; User ID=root; Password=root");

            
            public void openConnection()
            {
                if (connection.State == System.Data.ConnectionState.Closed) connection.Open();
            }
            public void closeConnection()
            {
                if (connection.State == System.Data.ConnectionState.Open) connection.Close();
            }
            public MySqlConnection GetConnection()
            {
                return connection;
            }
        }


        public Form1()
        {
            InitializeComponent();
            DB = new Database();
            table = new DataTable();
            adapter = new MySqlDataAdapter();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void loadButtom_Click(object sender, EventArgs e)
        {
            clearAll();
            DB.serverString = serverString.Text;
            DB.databaseString = databaseString.Text;
            DB.userString = userString.Text;
            DB.passwordString = passwordString.Text;
            DB.tableString = tableString.Text;
            DB.buildConnectionString();
            DB.openConnection();
            string SQLcommand = "select * from " + DB.tableString + ";";
            MySqlCommand command = new MySqlCommand(SQLcommand, DB.GetConnection());
            adapter.SelectCommand = command;
            adapter.Fill(table);
            dataGridView1.DataSource = table;
            DB.closeConnection();
        }

        private void clearAll()
        {
            table = new DataTable();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            dataGridView1.EndEdit();
            DataTable changeRows = table.GetChanges();
            if (changeRows != null)
            {
                MySqlCommandBuilder builder = new MySqlCommandBuilder(adapter);
                adapter.Update(changeRows);
                table.AcceptChanges();
                MessageBox.Show("Changes saved");

            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void findButton_Click(object sender, EventArgs e)
        {
            DB.openConnection();
            String findString = findTextBox.Text;
            MySqlCommand command = new MySqlCommand();
            String sqlCommand = "SELECT *  FROM " + DB.databaseString + "." + DB.tableString + " WHERE  ";
            String sqlParam;
            DataGridViewColumn col = dataGridView1.Columns[1];
            sqlParam = "@" + col.Name;
            sqlCommand += col.Name + "=" + sqlParam;
            if (col.ValueType == typeof(int))
                command.Parameters.Add(sqlParam, MySqlDbType.Int32).Value = Convert.ToInt32(findString);
            else
                command.Parameters.Add(sqlParam, MySqlDbType.VarChar).Value = findString;
            command.CommandText = sqlCommand;
            command.Connection = DB.GetConnection();
            adapter.SelectCommand = command;
            clearAll();
            adapter.Fill(table);
            dataGridView1.DataSource = table;
            DB.closeConnection();
        }

        private void resizeContent(object sender, EventArgs e)
        {
            dataGridView1.Width = Width - (dataGridView1.Location.X * 2) - (dataGridView1.Margin.All * 2) - 10;
        }

        private void findTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void executeButton_Click(object sender, EventArgs e)
        {
            clearAll();
            //String productString = productBox.Text;
            //String countString = countBox.Text;
            //String buyerString = buyerBox.Text;
            MySqlConnection con;
            con = new MySqlConnection();
            con.Open();
            MySqlCommand cmd = new MySqlCommand();
            string sql = "INSERT INTO ORDERS (id_user,ordertime,number,id_product)" + "VALUES(@buyerString,null,@countString,@productString,)";
            cmd.Parameters.AddWithValue("@buyerString", buyerBox.Text);
            cmd.Parameters.AddWithValue("@countString", countBox.Text);
            cmd.Parameters.AddWithValue("@productString", productBox.Text);
            try
            { cmd.ExecuteNonQuery(); }
            catch
            { MessageBox.Show("Облом!"); }
            finally { con.Close(); }
        }

        private void drawButton_Click(object sender, EventArgs e)
        {
            DB.openConnection();
            String axisXstring = textBox.Text;
            String axisYstring = textBox2.Text;
            String axisZstring = textBox3.Text;
            DB.tableString = tableString.Text;
            table.Clear();
            MySqlCommand command = new MySqlCommand();
            //string sqlCommand = "Select " + axisXstring + "," + axisYstring + " from " + DB.tableString + ";";
            string sqlCommand = "Select " + axisXstring + "," + axisYstring + "," +axisZstring+ " from " + DB.tableString + ";";
            command.CommandText = sqlCommand;
            command.Connection = DB.GetConnection();
            adapter.SelectCommand = command;
            adapter.Fill(table);
            DB.closeConnection();
            chart1.Series.Clear();
            chart1.Series.Add("Chart");
            chart1.Series["Chart"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Column;
            chart1.Series.Add("Chart1.2");
            chart1.Series["Chart1.2"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Column;

            chart1.Series.Add("Chart2");
            chart1.Series["Chart2"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            chart1.Series.Add("Chart2.2");
            chart1.Series["Chart2.2"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;


            for (int i = 0; i < table.Rows.Count; i++)
            {
                string xValue = (table.Rows[i][axisXstring].ToString());
                double yValue = Double.Parse(table.Rows[i][axisYstring].ToString());
                double zValue = Double.Parse(table.Rows[i][axisZstring].ToString());

                chart1.Series["Chart"].Points.AddXY(xValue, yValue);
                chart1.Series["Chart1.2"].Points.AddXY(xValue, zValue);

                chart1.Series["Chart2"].Points.AddXY(xValue, yValue);
                chart1.Series["Chart2.2"].Points.AddXY(xValue, zValue);

            }



        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }
    }
}
